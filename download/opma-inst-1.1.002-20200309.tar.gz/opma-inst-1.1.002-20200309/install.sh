#!/bin/sh

fnCheckAlreadyInstallForSystemd()
{
	if [ -f /etc/systemd/system/opmagent.service ]; then
		:
	else
		return 0
	fi

	#ExecStart=/infsw/opma/bin/start.sh
	startLine=`cat /etc/systemd/system/opmagent.service | grep -v "^#" | grep "ExecStart=" | head -1`
	#/infsw/opma/bin/start.sh
	filepath=`expr "X$startLine" : 'X.*ExecStart=\(.*\)'`
	binpath=`dirname $filepath`
	homepath=`dirname $binpath`

	if [ -f $filepath ]; then
		gUpdateMode="Y"
	fi

	gAlreadyInstalledOpmaHome="$homepath"
}

fnCheckAlreadyInstallForInitd()
{
	if [ "$gOsKind" = "Aix" ]; then
		initdScriptPath="/etc/rc.d/init.d/opmagent"
	else
		initdScriptPath="/etc/init.d/opmagent"
	fi

	if [ -f $initdScriptPath ]; then
		:
	else
		return 0
	fi

	filepath=`cat $initdScriptPath | grep -v "^#" | grep "start.sh" | head -1`
	binpath=`dirname $filepath`
	homepath=`dirname $binpath`

	if [ -f $filepath ]; then
		gUpdateMode="Y"
	fi

	gAlreadyInstalledOpmaHome="$homepath"
}

fnReadParam()
{
	paramList=`echo $@`

	set -- $paramList

	i=1 
	cnt=$#
	param=""

	while [ "$i" -le "$cnt" ]
	do
		param=$1
		if [ "$param" = "-f" ]; then
			gInterMode="N"
		elif [ "$param" = "-d" ]; then 
			i=`expr $i + 1`
			shift
			param=$1
			gOpmaHome=$param
		fi
		i=`expr $i + 1`
		shift
	done
}

fnGetBaseInfo()
{
	shellpath="$0"
	link=""
	while [ -h "$shellpath" ]; do
		ls=`ls -ld "$shellpath"`
		link=`expr "$ls" : '.*-> \(.*\)$'`
		if expr "$link" : '/.*' > /dev/null; then
			shellpath="$link"
		else
			shellpath=`dirname "$shellpath"`/"$link"
		fi
	done
	dirpath=`dirname $shellpath`
	gInstallerPath=`cd $dirpath; pwd -P`

	gOsKind=`uname -s`

	if [ "$gOsKind" = "Linux" ]; then
		gOsKind="Linux"
	elif [ "$gOsKind" = "AIX" ]; then
		gOsKind="Aix"
	elif [ "$gOsKind" = "SunOS" ]; then
		gOsKind="Sunos"
	else
		echo "Not yet supported OS ($gOsKind)!!!"
		exit 1
	fi
	gMachineKind=`uname -p`


	if [ "$gOsKind" = "Aix" ]; then
		gSvcType="initd"
	elif [ "$gOsKind" = "Sunos" ]; then
		gSvcType="initd"
	elif [ -f "/usr/bin/systemctl" ]; then
		gSvcType="systemd"
	elif [ -d "/etc/init.d" ]; then
		gSvcType="initd"
	else
		echo "Unknown Service Type!!!"
		exit 1
	fi
}

fnSelectBinary()
{
	filehead=""

	if [ "$gOsKind" = "Linux" ]; then
		filehead="Linux"
	elif [ "$gOsKind" = "Aix" ]; then
		filehead="Aix"
	elif [ "$gOsKind" = "Sunos" ]; then
		filehead="Sunos"
	else
		echo "Not yet supported OS ($gOsKind)!!!"
		exit 1
	fi

	if [ "$gMachineKind" = "x86_64" ]; then
		filehead="$filehead.x86_64"
	elif [ "$gMachineKind" = "i686" ]; then
		filehead="$filehead.x86_64"
	elif [ "$gMachineKind" = "powerpc" ]; then
		filehead="$filehead.ppc_64"
	elif [ "$gMachineKind" = "sparc" ]; then
		filehead="$filehead.sparc_64"
	else
		echo "Not yet supported OS ($gOsKind)!!!"
		exit 1
	fi

	cd $gInstallerPath/binary
	files=`ls $filehead*.gz 2> /dev/null`
	if [ "$files" = "" ]; then
		echo "Couldn't find the suitable binary!!!"
		exit 1
	fi
	cd $gInstallerPath

	if [ "$gOsKind" = "Linux" ]; then
		fnSelectBinaryVariationLinux "$files"
	elif [ "$gOsKind" = "Aix" ]; then
		fnSelectBinaryVariationAix "$files"
	elif [ "$gOsKind" = "Sunos" ]; then
		fnSelectBinaryVariationSunos "$files"
	else
		echo "Not yet supported OS ($gOsKind)!!!"
		exit 1
	fi
}

fnSelectBinaryVariationLinux()
{
	#glibc 2.12
	systemGlibc=`getconf GNU_LIBC_VERSION`
	#2.12
	systemGlibcVer=`expr "X$systemGlibc" : 'X.*glibc \(.*\)'`
	#21200
	systemGlibcVerNum=`fnVerToNum "$systemGlibcVer"`

	fileList=$1

	set -- $fileList

	linuxFileCnt=$#
	
	# get verNo for cmp
	verNumList=""
	linuxFileGlibcVerNum=""
	i=1
	while [ "$i" -le "$linuxFileCnt" ]
	do
		linuxFileGlibcVerNum=`fnGetLibcNo "$1"`
		verNumList="$verNumList $linuxFileGlibcVerNum"
		i=`expr $i + 1`
		shift
	done

	set -- $verNumList

	selectIdx=0
	maxVerNum=0
	linuxFileIdx=1
	while [ "$linuxFileIdx" -le "$linuxFileCnt" ]
	do
		if [ "$1" -le "$systemGlibcVerNum" ] && [ "$1" -gt "$maxVerNum" ]; then
			selectIdx=$linuxFileIdx
			maxVerNum=$1
		fi
		linuxFileIdx=`expr $linuxFileIdx + 1`
		shift
	done

	if [ "$selectIdx" -eq "0" ]; then
		echo "Couldn't find the suitable binary for glibc $systemGlibcVer !!!"
		exit 1
	fi

	set -- $fileList

	if [ "$selectIdx" -gt "1" ]; then
		selectIdx=`expr $selectIdx - 1`
		shift $selectIdx
	fi
	gInstallBinary="$1"
}

fnSelectBinaryVariationAix()
{
	fileList=$1

	set -- $fileList

	gInstallBinary=$1
}

fnSelectBinaryVariationSunos()
{
	fileList=$1

	set -- $fileList

	gInstallBinary=$1
}

fnGetLibcNo()
{
	# ex. Linux.x86_64.20180701.1.glibc-2.12.tar.gz
	# or  Linux.x86_64.20180701.1.glibc-2.3.4.tar.gz
	filename=$1
	
	# "2.12" or "2.3.4"
	linuxFileGlibcVer=`expr "X$filename" : 'X.*glibc-\(.*\)\.tar\.gz'`

	# 21200 or 20304
	glibcVerNum=`fnVerToNum "$linuxFileGlibcVer"`

	echo "$glibcVerNum"
}

fnVerToNum()
{
	# "2.12" or "2.3.4"
	verNo=$1

	# "2 12" or "2 3 4"
	noList=`echo $verNo | sed "s/\./ /g"`

	set -- $noList

	i=1 
	cnt=$#

	cmpInt=0
	no=0

	while [ "$i" -le "$cnt" ]
	do
		no=$1

		if [ "$i" -eq "1" ]; then
			cmpInt=`expr $cmpInt + $no \* 10000`
		elif [ "$i" -eq "2" ]; then
			cmpInt=`expr $cmpInt + $no \* 100`
		elif [ "$i" -eq "3" ]; then
			cmpInt=`expr $cmpInt + $no`
		else
			echo "Unexpected version string $verNo !!!"
			exit 1
		fi
		i=`expr $i + 1`
		shift
	done
	
	echo "$cmpInt"
}

fnInputOpmaHome()
{
	if [ "$gInterMode" = "N" ] || [ "$gOpmaHome" != "" ]; then
		return 0
	fi

	input=""
	str=""

	while true
	do
		printf "Input installation directory (ex. /infsw/opma) : "
		read input

		str=`echo "$input" | cut -b1`	
		len=`expr "$input" : '.*'`

		if [ "$str" = "/" ] && [ "$len" -ge 2 ]; then
			break;
		fi
	done

	gOpmaHome="$input"
}

fnConfirmInstallInfo()
{
	echo "=========================================================="
	echo " INSTALLATION INFORMATION"
	echo "=========================================================="
	if [ "$gUpdateMode" = "N" ]; then
		echo " MODE     : New installation"
	else
		echo " MODE     : Update installation"
	fi
	echo " LOCATION : $gOpmaHome"
	echo " SERVICE  : $gSvcType"
	echo " BINARY   : $gInstallBinary"
	echo "=========================================================="

	if [ "$gOpmaHome" = "" ]; then
		echo "Couldn't find installation location!!!"
		exit 1
	fi

	input=""

	if [ "$gInterMode" = "Y" ]; then

		printf "Input 'yes' to proceed installation : "
		read input

		if [ "$input" != "yes" ]; then
			exit 1
		fi
	fi
}

fnCheckAlreadyInstall()
{
	if [ "$gSvcType" = "systemd" ]; then
		fnCheckAlreadyInstallForSystemd
	elif [ "$gSvcType" = "initd" ]; then
		fnCheckAlreadyInstallForInitd
	fi


	if [ "$gUpdateMode" = "Y" ]; then
		if [ "$gOpmaHome" != "" ]; then
			echo "WARN: OpMate Agent had been installed already."
			echo "      Installation is proceeded in previous location ($gAlreadyInstalledOpmaHome)"
			echo "      Your input($gOpmaHome) for location is ignored!!!"
		fi
		gOpmaHome="$gAlreadyInstalledOpmaHome"
	fi
}

fnStopService()
{
	if [ "$gUpdateMode" = "N" ]; then
		return 0
	fi

	if [ -f $gOpmaHome/cfg/opmagent.pid ]; then
		:
	else
		return 0
	fi

	pid=`cat $gOpmaHome/cfg/opmagent.pid`
	psCnt=`ps -p $pid | grep opmagent | wc -l`

	if [ "$psCnt" -eq "0" ]; then
		return 0
	fi


	echo "Stopping OpMate Agent..."

	if [ "$gOsKind" = "Aix" ]; then
		$gOpmaHome/bin/stop.sh
	elif [ "$gOsKind" = "Sunos" ]; then
		$gOpmaHome/bin/stop.sh
	elif [ "$gSvcType" = "systemd" ]; then
		systemctl stop opmagent
	elif [ "$gSvcType" = "initd" ]; then
		service opmagent stop
	fi

	i=0 
	ret=0
	set +e
	while [ "$i" -lt "60" ]
	do
		sleep 1
		kill -0 $pid 2> /dev/null
		ret=$?
		if [ $ret -ne "0" ]; then
			break
		fi
		i=`expr $i + 1`
	done
	set -e
}

fnCheckUser()
{
	# whoami in solaris
	userid=`id | cut -d\( -f2 | cut -d\) -f1`

	if [ "$userid" != "root" ]; then
		echo "Must install as root!!!"
		exit 1
	fi
}

fnMakeDirs()
{
	if [ "$gOpmaHome" = "" ]; then
		echo "Something wrong : Stopping risky job"
		exit 1
	fi

	mkdir -p $gOpmaHome/bin
	mkdir -p $gOpmaHome/cfg
	mkdir -p $gOpmaHome/log
	mkdir -p $gOpmaHome/task/running
	mkdir -p $gOpmaHome/tmp

	dirList=`echo $gOpmaHome | sed "s/\// /g"`
	str=""

	set -- $dirList

	path=""
	i=1 
	cnt=$#
	while [ "$i" -le "$cnt" ]
	do
		path="$path/$1"
		chmod 755 $path
		i=`expr $i + 1`
		shift
	done

	chmod 755 $gOpmaHome/bin $gOpmaHome/cfg $gOpmaHome/task $gOpmaHome/task/running $gOpmaHome/tmp
}

fnCopyFiles()
{
	if [ "$gOpmaHome" = "" ]; then
		echo "Something wrong : Stopping risky job"
		exit 1
	fi

	installBinaryDir=`expr "X$gInstallBinary" : 'X\(.*\)\.tar\.gz'`

	# extract binary
	cd $gInstallerPath/binary

	if [ -d "./$installBinaryDir" ]
	then
		rm -rf ./$installBinaryDir
	fi

	gunzip -c $gInstallBinary | tar -xvf - > /dev/null

	# delete deprecated file
	rm -f $gOpmaHome/lib/libopmcore.so
	rm -f $gOpmaHome/lib/libopmds.so
	rm -f $gOpmaHome/lib/libopmutil.so
	if [ -e $gOpmaHome/lib ]; then
		rmdir $gOpmaHome/lib
	fi

	# copy binary
	cp -f $installBinaryDir/bin/* $gOpmaHome/bin/
	chmod 755 $gOpmaHome/bin/opmagent
	chmod 755 $gOpmaHome/bin/opmfileget
	chmod 755 $gOpmaHome/bin/opmfileput
	chmod 755 $gOpmaHome/bin/opmfilels

	# copy bin(shell)
	cd $gInstallerPath
	cp -f $gInstallerPath/rsc/bin/*.sh $gOpmaHome/bin/
	chmod 755 $gOpmaHome/bin/*.sh

	# copy bin(cfg)
	if [ "$gUpdateMode" = "N" ]; then
		cp -f $gInstallerPath/rsc/cfg/agent.conf.tpl $gOpmaHome/cfg/agent.conf
		cp -f $gInstallerPath/rsc/cfg/agent.guid     $gOpmaHome/cfg/agent.guid
	fi
	chmod 644 $gOpmaHome/cfg/agent.conf
	chmod 644 $gOpmaHome/cfg/agent.guid

	# copy svc
	initdScriptPath=""
	if [ "$gOsKind" = "Aix" ]; then
		initdScriptPath="/etc/rc.d/init.d/opmagent"
	else
		initdScriptPath="/etc/init.d/opmagent"
	fi

	if [ "$gSvcType" = "systemd" ]; then
		cat $gInstallerPath/rsc/svc/opmagent.service.tpl | sed "s#@OPMA_HOME@#$gOpmaHome#g" > /etc/systemd/system/opmagent.service
		systemctl daemon-reload
	elif [ "$gSvcType" = "initd" ]; then
		cat $gInstallerPath/rsc/svc/opmagent.tpl | sed "s#@OPMA_HOME@#$gOpmaHome#g" > $initdScriptPath
		chmod 755 $initdScriptPath
	fi

	# create symbolic link
	rm -f /usr/bin/opmfget
	ln -s $gOpmaHome/bin/opmfget.sh /usr/bin/opmfget

	rm -f /usr/bin/opmfput
	ln -s $gOpmaHome/bin/opmfput.sh /usr/bin/opmfput
	
	rm -f /usr/bin/opmfls
	ln -s $gOpmaHome/bin/opmfls.sh /usr/bin/opmfls
}


fnShowResult()
{
	echo "OpMate Agent has been installed in \"$gOpmaHome\" successfully."

	if [ "$gUpdateMode" = "N" ]; then
		echo ""
		echo "Before starting the agent,"
		echo "You MUST edit the config file ($gOpmaHome/cfg/agent.conf)!!!"
	fi

	echo ""

	if [ "$gOsKind" = "Aix" ]; then
		echo "To start the agent service, run '$gOpmaHome/bin/start.sh'"
	elif [ "$gOsKind" = "Sunos" ]; then
		echo "To start the agent service, run '$gOpmaHome/bin/start.sh'"
	elif [ "$gSvcType" = "systemd" ]; then
		echo "To start the agent service, run 'systemctl start opmagent'"
	elif [ "$gSvcType" = "initd" ]; then
		echo "To start the agent service, run 'service opmagent start'"
	fi

	if [ "$gUpdateMode" = "N" ]; then
		echo ""
		echo "To start/stop Automatically the agent, run the following command."
		if [ "$gOsKind" = "Aix" ]; then
			echo " 'ln -s /etc/rc.d/init.d/opmagent /etc/rc.d/rc2.d/S99opmagent'"
			echo " 'ln -s /etc/rc.d/init.d/opmagent /etc/rc.d/rc2.d/K01opmagent'"
		elif [ "$gOsKind" = "Sunos" ]; then
			echo " 'ln -s /etc/init.d/opmagent /etc/rc3.d/S99opmagent'"
			echo " 'ln -s /etc/init.d/opmagent /etc/rc3.d/K01opmagent'"
		elif [ "$gSvcType" = "systemd" ]; then
			echo " 'systemctl enable opmagent'"
		elif [ "$gSvcType" = "initd" ]; then
			echo " 'chkconfig --add opmagent'"
		fi
	fi
}

###############################################################################
# global variables
###############################################################################

# BaseInfo
gInstallerPath=""
gOsKind="" # Linux, Aix, Sunos
gMachineKind="" # x86_64, powerpc, sparc
gSvcType="" # systemd, initd
gInstallBinary="" # Linux.x86_64.20180701.1.glibc-2.12.tar.gz

# Mode
gInterMode="Y"  # Y : Interactive, N : Non-interactive
gUpdateMode="N" # Y : Update, N : New install

# ETC
gOpmaHome=""
gAlreadyInstalledOpmaHome=""

###############################################################################
# main
###############################################################################

set -e # exit on error

fnCheckUser

fnGetBaseInfo

fnSelectBinary

fnReadParam $@

fnCheckAlreadyInstall

fnInputOpmaHome

fnConfirmInstallInfo

fnStopService

fnMakeDirs

fnCopyFiles

fnShowResult

exit 0

