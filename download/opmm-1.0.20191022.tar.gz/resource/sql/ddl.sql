-----------------------------------------------------------
-- 테이블 삭제
-----------------------------------------------------------

--DROP TABLE IF EXISTS OPMATE_USER_GROUP_MEMBER;
--DROP TABLE IF EXISTS OPMATE_USER_GROUP;
--DROP TABLE IF EXISTS OPMATE_USER;
--DROP TABLE IF EXISTS OPMATE_NODE_GROUP_MEMBER;
--DROP TABLE IF EXISTS OPMATE_NODE_GROUP_ATTR;
--DROP TABLE IF EXISTS OPMATE_NODE_GROUP;
--DROP TABLE IF EXISTS OPMATE_NODE_ORDER;
--DROP TABLE IF EXISTS OPMATE_NODE;
--DROP TABLE IF EXISTS OPMATE_TASK_TARGET;
--DROP TABLE IF EXISTS OPMATE_TASK_RUNNER;
--DROP TABLE IF EXISTS OPMATE_TASK_SCHEDULE;
--DROP TABLE IF EXISTS OPMATE_TASK_INSTANCE_NODE;
--DROP TABLE IF EXISTS OPMATE_TASK_INSTANCE;
--DROP TABLE IF EXISTS OPMATE_TASK;
--DROP TABLE IF EXISTS OPMATE_DIC;
--DROP TABLE IF EXISTS OPMATE_SYSTEM;
--DROP TABLE IF EXISTS OPMATE_NOTI;


-----------------------------------------------------------
-- 변경
-----------------------------------------------------------

-- Version > OPMM Version 1.0.20190806
ALTER TABLE OPMATE_NODE_GROUP MODIFY NODE_GROUP_ID VARCHAR(50) NOT NULL;

-- Version > OPMM Version 1.0.20190614
ALTER TABLE OPMATE_TASK ADD CERT_STATUS VARCHAR(1) NOT NULL DEFAULT 'N';


-- Version > OPMM Version 1.0.20190531
ALTER TABLE OPMATE_TASK MODIFY SCRIPT_NM VARCHAR(200) NOT NULL;
ALTER TABLE OPMATE_TASK MODIFY OS_USER   VARCHAR(20)  NOT NULL;


-- Version > OPMM Version 0.9.20190418
ALTER TABLE OPMATE_TASK MODIFY NEXT_TASK_NO INT(10) UNSIGNED NULL;

ALTER TABLE OPMATE_TASK_INSTANCE_NODE ADD RUNNER_NO INT(10) UNSIGNED NULL AFTER END_DT;
ALTER TABLE OPMATE_TASK_INSTANCE_NODE ADD RUNNER_GUBUN VARCHAR(1) NULL AFTER RUNNER_NO;

UPDATE OPMATE_TASK_INSTANCE_NODE
SET RUNNER_NO = (
                 SELECT RUNNER_NO
                 FROM OPMATE_TASK_INSTANCE
                 WHERE TASK_INSTANCE_NO = OPMATE_TASK_INSTANCE_NODE.TASK_INSTANCE_NO);
                 
UPDATE OPMATE_TASK_INSTANCE_NODE
SET RUNNER_GUBUN = (
                 SELECT RUNNER_GUBUN
                 FROM OPMATE_TASK_INSTANCE
                 WHERE TASK_INSTANCE_NO = OPMATE_TASK_INSTANCE_NODE.TASK_INSTANCE_NO);
                 
ALTER TABLE OPMATE_TASK_INSTANCE_NODE MODIFY RUNNER_NO INT(10) UNSIGNED NOT NULL;
ALTER TABLE OPMATE_TASK_INSTANCE_NODE MODIFY RUNNER_GUBUN VARCHAR(1) NOT NULL;




-----------------------------------------------------------
-- 테이블 생성
-----------------------------------------------------------

-- 사용자
-- OPMATE_USER : 사용자 테이블
CREATE TABLE IF NOT EXISTS OPMATE_USER
(
    USER_NO     INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, -- 사용자번호
    USER_ID     VARCHAR(20)      NOT NULL,                -- 사용자ID
    USER_PWD    VARCHAR(50)      NULL,                    -- 패스워드
    USER_NM     VARCHAR(30)      NULL,                    -- 사용자이름
    PHONE_NUM   VARCHAR(15)      NULL,                    -- 전화번호
    EMAIL       VARCHAR(50)      NULL,                    -- E-mail주소
    ROLE        INT(1) UNSIGNED  NULL     DEFAULT 3,      -- 역할(0:관리자, 1:검토자, 2:작업자, 3:관람자)
    STATUS      VARCHAR(1)       NULL     DEFAULT 'D',    -- 상태 (E: enable, D: disable)
    DESCRIPTION VARCHAR(500)     NULL,                    -- 설명
    PRIMARY KEY(USER_NO),
    UNIQUE KEY(USER_ID)
);

-- OPMATE_USER_GROUP : 사용자 그룹 테이블
CREATE TABLE IF NOT EXISTS OPMATE_USER_GROUP
(
    USER_GROUP_NO INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,  -- 사용자그룹번호
    USER_GROUP_ID VARCHAR(20)      NOT NULL,                 -- 사용자그룹ID
    OWNER         INT(10) UNSIGNED NULL,                     -- 소유자(OPMATE_USER.USER_NO)
    DESCRIPTION   VARCHAR(500)     NULL,                     -- 설명
    PRIMARY KEY(USER_GROUP_NO),
    UNIQUE KEY(USER_GROUP_ID)
);

-- OPMATE_USER_GROUP_MEMBER : 그룹별 소속사용자 테이블
CREATE TABLE IF NOT EXISTS OPMATE_USER_GROUP_MEMBER
(
    USER_GROUP_NO INT(10) UNSIGNED NOT NULL, -- 사용자그룹번호
    USER_NO       INT(10) UNSIGNED NOT NULL, -- 사용자번호
    PRIMARY KEY(USER_GROUP_NO, USER_NO)
);

-- 노드
-- OPMATE_NODE : 노드 테이블
CREATE TABLE IF NOT EXISTS OPMATE_NODE
(
    NODE_NO      INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, -- 노드번호
    NODE_ID      VARCHAR(50)      NOT NULL,                -- 노드ID
    AGENT_GUID   VARCHAR(50)      NOT NULL,                -- 에이전트 GUID
    CRYPTO_KEY   VARCHAR(172)     NOT NULL,                -- 암호화 Key (1024bits, 128bytes, base64=172bytes)
    AGENT_VER    VARCHAR(50)      NOT NULL,                -- 에이전트 Version
    OS_NAME      VARCHAR(10)      NOT NULL,                -- 운영체제명
    IP           VARCHAR(20)      NOT NULL,                -- IP
    HOSTNAME     VARCHAR(50)      NOT NULL,                -- HOSTNAME
    STATUS       VARCHAR(1)       NOT NULL DEFAULT 'D',    -- 상태 (E: enable, D: disable)
    HEARTBEAT_DT VARCHAR(14)      NOT NULL,                -- 최근 신호 수신 시간
    DESCRIPTION  VARCHAR(500)     NULL,                    -- 설명
    OWNER        INT(10) UNSIGNED NULL,                    -- 소유자(OPMATE_USER.USER_NO)
    CRT_DT       VARCHAR(14)      NOT NULL,                -- 생성 시간
    PRIMARY KEY(NODE_NO),
    UNIQUE  KEY(NODE_ID),
    UNIQUE  KEY(AGENT_GUID)
);

-- OPMATE_NODE_GROUP : 노드 그룹 테이블
CREATE TABLE IF NOT EXISTS OPMATE_NODE_GROUP
(
    NODE_GROUP_NO INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,  -- 노드그룹번호
    NODE_GROUP_ID VARCHAR(50)      NOT NULL,                 -- 노드그룹ID
    OWNER         INT(10) UNSIGNED NULL,                     -- 소유자(OPMATE_USER.USER_NO)
    DESCRIPTION   VARCHAR(500)     NULL,                     -- 설명
    PRIMARY KEY(NODE_GROUP_NO),
    UNIQUE KEY(NODE_GROUP_ID)
);

-- OPMATE_NODE_GROUP_MEMBER : 노드그룹별 소속 노드 테이블
CREATE TABLE IF NOT EXISTS OPMATE_NODE_GROUP_MEMBER
(
    NODE_GROUP_NO INT(10) UNSIGNED NOT NULL,  -- 노드그룹번호
    NODE_NO       INT(10) UNSIGNED NOT NULL,  -- 노드번호
    PRIMARY KEY(NODE_GROUP_NO, NODE_NO)
);

-- OPMATE_NODE_GROUP_ATTR : 노드그룹별 속성 테이블
CREATE TABLE IF NOT EXISTS OPMATE_NODE_GROUP_ATTR
(
    NODE_GROUP_NO INT(10) UNSIGNED NOT NULL,  -- 노드그룹번호
    ATTR_KEY      VARCHAR(100)     NOT NULL,  -- 속성키
    ATTR_VALUE    VARCHAR(300)     NOT NULL,  -- 속성값
    PRIMARY KEY(NODE_GROUP_NO, ATTR_KEY)
);

-- OPMATE_NODE_ORDER : 노드별 오더
CREATE TABLE IF NOT EXISTS OPMATE_NODE_ORDER
(
    NODE_ORDER_NO BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT, -- 노드오더번호
    NODE_NO       INT(10) UNSIGNED    NOT NULL,                -- 노드번호
    KIND          VARCHAR(20)         NOT NULL,                -- 오더 유형 (ex: taskRun)
    PARAM         VARCHAR(200)        NULL,                    -- 오더 파라미터
    PRIORITY      INT(1) UNSIGNED     NOT NULL DEFAULT 5,      -- 우선순위 (1~9)
    STATUS        VARCHAR(1)          NOT NULL,                -- 상태코드 (N: Not yet receive, R: Received)
    CRT_DT        VARCHAR(14)         NOT NULL,                -- 생성 시간
    PRIMARY KEY(NODE_ORDER_NO)
);
CREATE INDEX IDX_OPMATE_NODE_ORDER1 ON OPMATE_NODE_ORDER (NODE_NO, NODE_ORDER_NO);

-- 태스크
-- OPMATE_TASK : 태스크 정의 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK
(
    TASK_NO        INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, -- 태스크번호
    TASK_ID        VARCHAR(100)     NOT NULL,                -- 태스크ID
    REVISION_NO    INT(5) UNSIGNED  NOT NULL,                -- 태스크리비젼번호
    OWNER          INT(10) UNSIGNED NOT NULL,                -- 소유자(OPMATE_USER.USER_NO)
    SCRIPT_NM      VARCHAR(200)     NOT NULL,                -- 스크립트명
    OS_USER        VARCHAR(20)      NOT NULL,                -- 실행 OS User명
    EXEC_SCHEDULER VARCHAR(1)       NOT NULL DEFAULT 'D',    -- 스케쥴러에 의한 실행(E: enable, D: disable)
    EXEC_ONDEMAND  VARCHAR(1)       NOT NULL DEFAULT 'D',    -- 온디맨드 실행(E: enable, D: disable)
    EXEC_TASK      VARCHAR(1)       NOT NULL DEFAULT 'D',    -- 다른태스크에 의한 실행(E: enable, D: disable)
    NEXT_TASK_NO   INT(10) UNSIGNED NULL,                    -- NEXT태스크NO (OPMATE_TASK.TASK_NO)
    EXEC_CNT       INT(5) UNSIGNED  NOT NULL DEFAULT 0,      -- 태스크 동시수행개수 (0: 전체동시수행)
    APPRV_STATUS   VARCHAR(1)       NOT NULL DEFAULT 'N',    -- 승인상태(N: N/A, Q: 요청, A: 수락, R: 반려)
    APPRV_REQ_CMNT VARCHAR(400)     NULL,                    -- 승인 요청 의견
    APPRV_RJT_CMNT VARCHAR(400)     NULL,                    -- 승인 반려 의견
    APPRV_USER_NO  INT(10) UNSIGNED NULL,                    -- 승인자(OPMATE_USER.USER_NO)
    DESCRIPTION    VARCHAR(500)     NULL,                    -- 설명
    CERT_STATUS    VARCHAR(1)       NOT NULL DEFAULT 'N',    -- 인증상태(N: N/A, Q: 요청, C: 인증)
    PRIMARY KEY(TASK_NO),
    UNIQUE KEY(TASK_ID, REVISION_NO)
);

-- OPMATE_TASK_TARGET : 태스크 수행 대상 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK_TARGET
(
    TASK_NO      INT(10) UNSIGNED NOT NULL, -- 태스크번호
    TARGET_NO    INT(10) UNSIGNED NOT NULL, -- 타겟 번호(OPMATE_NODE.NODE_NO or OPMATE_NODE_GROUP.NODE_GROUP_NO)
    TARGET_GUBUN VARCHAR(1),                -- 타겟 구분(N: 노드, G: 노드그룹)
    PRIMARY KEY(TASK_NO, TARGET_NO, TARGET_GUBUN)
);

-- OPMATE_TASK_RUNNER : 태스크 실행가능자 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK_RUNNER
(
    TASK_NO      INT(10) UNSIGNED NOT NULL, -- 태스크번호
    RUNNER_NO    INT(10) UNSIGNED NOT NULL, -- 실행가능자 번호(OPMATE_USER.USER_NO or OPMATE_USER_GROUP.USER_GROUP_NO or OPMATE_TASK.TASK_NO)
    RUNNER_GUBUN VARCHAR(1),                -- 사용자 구분(U: 단일사용자, G: 사용자그룹, T: 태스크)
    PRIMARY KEY(TASK_NO, RUNNER_NO, RUNNER_GUBUN)
);

-- OPMATE_TASK_SCHEDULE : 태스크 스케쥴 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK_SCHEDULE
(
    TASK_SCHEDULE_NO INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, -- 스케쥴번호
    TASK_SCHEDULE_ID VARCHAR(20)      NOT NULL,                -- 스케쥴ID
    TASK_NO          INT(10) UNSIGNED NOT NULL,                -- 태스크번호
    CYCLE_CD         VARCHAR(1)       NOT NULL,                -- 주기(Y:yearly, M:monthly, W:weekly, D:daily, H:hourly, O:once)
    YEAR             INT(4) UNSIGNED  NULL,                    -- 년도
    MONTH            INT(2) UNSIGNED  NULL,                    -- 월(1~12)
    DAY              INT(2) UNSIGNED  NULL,                    -- 일(1~31)
    HOUR             INT(2) UNSIGNED  NULL,                    -- 시간(0~23)
    MINUTE           INT(2) UNSIGNED  NULL,                    -- 분(0~59)
    DAYOFWEEK        INT(1) UNSIGNED  NULL,                    -- 요일(0~6, 0: 일요일)
    ABLE             VARCHAR(1)       NOT NULL,                -- 활성상태 (E: enable, D: disable)
    PRIMARY KEY(TASK_SCHEDULE_NO),
    UNIQUE KEY(TASK_NO, TASK_SCHEDULE_ID)
);
CREATE INDEX IDX_OPMATE_TASK_SCHEDULE1 ON OPMATE_TASK_SCHEDULE (ABLE);

-- OPMATE_TASK_INSTANCE : 태스크 인스턴스 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK_INSTANCE
(
    TASK_INSTANCE_NO      BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT, -- 인스턴스번호
    TASK_NO               INT(10) UNSIGNED    NOT NULL,                -- 태스크번호
    START_DT              VARCHAR(14)         NULL,                    -- 실행시작일시
    END_DT                VARCHAR(14)         NULL,                    -- 실행종료일시
    RUNNER_NO             INT(10) UNSIGNED    NOT NULL,                -- 실행자번호(0:삭제된러너, OPMATE_TASK_SCHEDULE.TASK_SCHEDULE_NO, OPMATE_USER.USER_NO, OPMATE_TASK.TASK_NO)
    RUNNER_GUBUN          VARCHAR(1)          NOT NULL,                -- 실행자구분(S: By Scheduler, U: By On-Demand, T: By Another Task)
    SCRIPT_PARM           VARCHAR(500)        NULL,                    -- 스크립트 실행 Parameter(Command Line Parameter)
    NEXT_TASK_INSTANCE_NO BIGINT(20) UNSIGNED NULL,                    -- NEXT태스크의 인스턴스 번호
    PRIMARY KEY(TASK_INSTANCE_NO)
);

-- OPMATE_TASK_INSTANCE_NODE : 노드별 태스크 인스턴스 테이블
CREATE TABLE IF NOT EXISTS OPMATE_TASK_INSTANCE_NODE
(
    TASK_INSTANCE_NO BIGINT(20) UNSIGNED NOT NULL,             -- 인스턴스번호
    NODE_NO          INT(10) UNSIGNED    NOT NULL,             -- 노드번호
    EXEC_NO          INT(5) UNSIGNED     NOT NULL,             -- 실행회차
    STATUS           VARCHAR(1)          NOT NULL,             -- 상태(R: 대기중, C: 요청완료, S: 회신완료, F: 실패)
    START_DT         VARCHAR(14)         NULL,                 -- 실행시작일시(노드기준시간)
    END_DT           VARCHAR(14)         NULL,                 -- 실행종료일시(노드기준시간)
    RUNNER_NO        INT(10) UNSIGNED    NOT NULL,             -- 실행자번호(0:삭제된러너, OPMATE_TASK_SCHEDULE.TASK_SCHEDULE_NO, OPMATE_USER.USER_NO, OPMATE_TASK.TASK_NO)
    RUNNER_GUBUN     VARCHAR(1)          NOT NULL,             -- 실행자구분(S: By Scheduler, U: By On-Demand, T: By Another Task)
    RESULT_CD        VARCHAR(1)          NOT NULL DEFAULT 'N', -- 실행결과(N: N/A, S: 성공, F: 실패)
    EXIT_CD          INT(10)             NULL,                 -- 종료리턴코드(0:정상, 1~255:에러, 256~:특수에러)
    PRIMARY KEY(TASK_INSTANCE_NO, NODE_NO, EXEC_NO)
);

-- 기타
-- OPMATE_DIC : 사전 테이블
CREATE TABLE IF NOT EXISTS OPMATE_DIC
(
    DIC_NO INT(10) UNSIGNED NOT NULL AUTO_INCREMENT, -- 사전번호
    WORD   VARCHAR(100)     NOT NULL,                -- 단어
    KIND   VARCHAR(1)       NOT NULL,                -- 구분(R: RISK)
    PRIMARY KEY(DIC_NO)
);

-- OPMATE_SYSTEM : 시스템 테이블
CREATE TABLE IF NOT EXISTS OPMATE_SYSTEM
(
    SYS_KEY VARCHAR(20)  NOT NULL, -- 항목키
    SYS_VAL VARCHAR(200) NULL,     -- 항목값
    PRIMARY KEY(SYS_KEY)
);

-- OPMATE_NOTI : 알림 테이블
CREATE TABLE IF NOT EXISTS OPMATE_NOTI
(
    NOTI_NO  BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT, -- 알림번호
    SENDER   VARCHAR(100)        NULL,                    -- 보내는사람
    RECEIVER VARCHAR(1000)       NOT NULL,                -- 받는사람
    CONTENT  VARCHAR(4000)       NULL,                    -- 내용
    STATUS   VARCHAR(1)          NOT NULL,                -- 상태코드 (R: Ready, S: Send)
    CRT_DT   VARCHAR(14)         NOT NULL,                -- 생성 시간
    PRIMARY KEY(NOTI_NO)
);
CREATE INDEX IDX_OPMATE_NOTI1 ON OPMATE_NOTI (STATUS);
CREATE INDEX IDX_OPMATE_NOTI2 ON OPMATE_NOTI (CRT_DT);


-----------------------------------------------------------
-- 외래키 삭제
-----------------------------------------------------------

--SELECT CONCAT('ALTER TABLE ', table_name, ' DROP FOREIGN KEY ', constraint_name, ';')
--FROM information_schema.table_constraints WHERE constraint_type = 'FOREIGN KEY';


-----------------------------------------------------------
-- 외래키 생성
-----------------------------------------------------------

-- OPMATE_USER_GROUP_MEMBER

ALTER TABLE OPMATE_USER_GROUP_MEMBER ADD CONSTRAINT OPMATE_USER_GROUP_MEMBER_fk1
    FOREIGN KEY (USER_GROUP_NO) REFERENCES OPMATE_USER_GROUP(USER_GROUP_NO);

ALTER TABLE OPMATE_USER_GROUP_MEMBER ADD CONSTRAINT OPMATE_USER_GROUP_MEMBER_fk2
    FOREIGN KEY (USER_NO) REFERENCES OPMATE_USER(USER_NO);


-- OPMATE_NODE_GROUP_MEMBER

ALTER TABLE OPMATE_NODE_GROUP_MEMBER ADD CONSTRAINT OPMATE_NODE_GROUP_MEMBER_fk1
    FOREIGN KEY (NODE_GROUP_NO) REFERENCES OPMATE_NODE_GROUP(NODE_GROUP_NO);

ALTER TABLE OPMATE_NODE_GROUP_MEMBER ADD CONSTRAINT OPMATE_NODE_GROUP_MEMBER_fk2
    FOREIGN KEY (NODE_NO) REFERENCES OPMATE_NODE(NODE_NO);
    

-- OPMATE_NODE_GROUP_ATTR

ALTER TABLE OPMATE_NODE_GROUP_ATTR ADD CONSTRAINT OPMATE_NODE_GROUP_ATTR_fk1
    FOREIGN KEY (NODE_GROUP_NO) REFERENCES OPMATE_NODE_GROUP(NODE_GROUP_NO);


-- OPMATE_NODE_ORDER

ALTER TABLE OPMATE_NODE_ORDER ADD CONSTRAINT OPMATE_NODE_ORDER_fk1
    FOREIGN KEY (NODE_NO) REFERENCES OPMATE_NODE(NODE_NO);


-- OPMATE_TASK_TARGET

ALTER TABLE OPMATE_TASK_TARGET ADD CONSTRAINT OPMATE_TASK_TARGET_fk1
    FOREIGN KEY (TASK_NO) REFERENCES OPMATE_TASK(TASK_NO);


-- OPMATE_TASK_RUNNER

ALTER TABLE OPMATE_TASK_RUNNER ADD CONSTRAINT OPMATE_TASK_RUNNER_fk1
    FOREIGN KEY (TASK_NO) REFERENCES OPMATE_TASK(TASK_NO);


-- OPMATE_TASK_SCHEDULE

ALTER TABLE OPMATE_TASK_SCHEDULE ADD CONSTRAINT OPMATE_TASK_SCHEDULE_fk1
    FOREIGN KEY (TASK_NO) REFERENCES OPMATE_TASK(TASK_NO);


-- OPMATE_TASK_INSTANCE

ALTER TABLE OPMATE_TASK_INSTANCE ADD CONSTRAINT OPMATE_TASK_INSTANCE_fk1
    FOREIGN KEY (TASK_NO) REFERENCES OPMATE_TASK(TASK_NO);


-- OPMATE_TASK_INSTANCE_NODE

ALTER TABLE OPMATE_TASK_INSTANCE_NODE ADD CONSTRAINT OPMATE_TASK_INSTANCE_NODE_fk1
    FOREIGN KEY (TASK_INSTANCE_NO) REFERENCES OPMATE_TASK_INSTANCE(TASK_INSTANCE_NO);

ALTER TABLE OPMATE_TASK_INSTANCE_NODE ADD CONSTRAINT OPMATE_TASK_INSTANCE_NODE_fk2
    FOREIGN KEY (NODE_NO) REFERENCES OPMATE_NODE(NODE_NO);



