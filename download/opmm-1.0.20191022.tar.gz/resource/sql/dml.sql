-----------------------------------------------------------
-- 초기값
-----------------------------------------------------------
	
-- OPMATE_USER (insert admin info)
INSERT INTO OPMATE_USER
	(USER_ID, USER_PWD, USER_NM, PHONE_NUM, EMAIL, ROLE, STATUS, DESCRIPTION)
	VALUES ('admin', 'paMLxMR4iM1ZxOnfaNgCQg==', 'admin', '010-1234-5678', 'admin@example.com', 0, 'E', 'admin계정입니다.');
	
-- OPMATE_SYSTEM
INSERT INTO OPMATE_SYSTEM (SYS_KEY, SYS_VAL)
	VALUES ('SCHEDULER_CHECK_TIME', NULL);
	
-- OPMATE_DIC
INSERT INTO OPMATE_DIC (KIND, WORD)	VALUES ('R', 'halt');
INSERT INTO OPMATE_DIC (KIND, WORD)	VALUES ('R', 'reboot');
INSERT INTO OPMATE_DIC (KIND, WORD)	VALUES ('R', 'rm -rf');
INSERT INTO OPMATE_DIC (KIND, WORD)	VALUES ('R', 'shutdown');
INSERT INTO OPMATE_DIC (KIND, WORD)	VALUES ('R', 'umount');
